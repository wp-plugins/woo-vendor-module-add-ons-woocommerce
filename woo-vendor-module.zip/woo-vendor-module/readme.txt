=== Woo vendor module ===
Contributors: woocommerce
Tags: woo vendor,vendor,vendor system,vendor shop,product vendor,product vendors,seller,shop
Requires at least: 3.1
Tested up to: 4.1.1
Stable tag: 3.0.4

Woo vendor is used with woocommerce plugin for creating an vendor system.It also works for product management with vendor ,provide vendor shop with unique URL as well as manage the commission of vendor .

== Description ==

Woo vendor is used with woocommerce plugin for creating an vendor system.It also works for product management with vendor ,provide vendor shop with unique URL as well as manage the commission of vendor.Administrator have full power to prevent any vendor as well as allow it's shop on own website.

Major features in woo vendor include:

* When any user registered then it will waiting for admin approval .After approval it will works as an vendor.
* Admin will approves the every vendor then it will responsible for creating an woocommerce product and make an shop.
* Vendor have the own unique SHOP url so it can also be pramote it. 

* Admin have the power to remove any shop on any time.
* Admin will manage the commission of any vendor and will responsible for due it also .
* When any product created by the vendor then it will wait for admin approval, after that it will display on frontend. 

* Vendor can pramote the own shop URL.
* When vendor create product then it will waiting for admin approval.After that it will display on frontend.

== Installation ==

1. Upload `woo vendor module` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. After activating check all the settings on below path : Admin Menu : woocommerce -> woo vendors.

== Screenshots ==
1. screenshot-main.png : it have a short summary of the Backend and shop of frontend.
2. screenshot-1.png    : Admin module general setting.
3. screenshot-2.png    : Admin module page settings.
4. screenshot-3.png    : Admin module commission settings.
5. screenshot-4.png    : Frontend Myaccount information .
6. screenshot-5.png    : Vendor order history.
7. screenshot-shop.png : Vendor shop with unique URL.



== Changelog ==

= 1.0 =
*Release Date - 27th Feb, 2015*

