/*
 *js file
 *Ref: Date picker : http://jqueryui.com/datepicker/#animation
 *http://api.jqueryui.com/datepicker/#entry-examples
 */

jQuery(document).ready(function($){
    
    //date picker
    $( "#datepicker_from" ).datepicker();
    $( "#datepicker_to" ).datepicker();
    
});//end of the dom ready.