<?php
/* 
 *This file customize the myaccount page and added the own functionality 
 */

include_once WOO_VENDOR__PLUGIN_DIR.'pages/myaccount/wv-vendorlinks-in-myaccount.php';